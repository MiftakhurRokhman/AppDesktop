﻿Public Class ClsEntMobil
    Private kode_mobil As String
    Private merk_mobil As String
    Private nomor_kendaraan As String
    Private warna_mobil As String
    Private tarif_mobil As String
    Private tahun_mobil As String
    Private status_mobil As String

    Public Property KodeMobil() As String
        Get
            Return kode_mobil
        End Get
        Set(value As String)
            kode_mobil = value
        End Set
    End Property

    Public Property MerkMobil() As String
        Get
            Return merk_mobil
        End Get
        Set(value As String)
            merk_mobil = value
        End Set
    End Property

    Public Property NomorKendaraan() As String
        Get
            Return nomor_kendaraan
        End Get
        Set(value As String)
            nomor_kendaraan = value
        End Set
    End Property

    Public Property Warnamobil() As String
        Get
            Return warna_mobil
        End Get
        Set(value As String)
            warna_mobil = value
        End Set
    End Property

    Public Property TarifMobil() As String
        Get
            Return tarif_mobil
        End Get
        Set(value As String)
            tarif_mobil = value
        End Set
    End Property

    Public Property TahunMobil() As String
        Get
            Return tahun_mobil
        End Get
        Set(value As String)
            tahun_mobil = value
        End Set
    End Property

    Public Property StatusMobil() As String
        Get
            Return status_mobil
        End Get
        Set(value As String)
            status_mobil = value
        End Set
    End Property
End Class
