﻿Public Class ClsEntPinjam
    Private kode_pinjam As String
    Private kode_admin As String
    Private kode_mobil As String
    Private tgl_pinjam As Date
    Private tgl_kembali As Date
    Private kode_pelanggan As String
    Private bayar As String
    Private status_pinjam As String

    Public Property KodePinjam() As String
        Get
            Return kode_pinjam
        End Get
        Set(value As String)
            kode_pinjam = value
        End Set
    End Property

    Public Property KodeAdmin() As String
        Get
            Return kode_admin
        End Get
        Set(value As String)
            kode_admin = value
        End Set
    End Property

    Public Property KodeMobil() As String
        Get
            Return kode_mobil
        End Get
        Set(value As String)
            kode_mobil = value
        End Set
    End Property


    Public Property TglPinjam() As Date
        Get
            Return tgl_pinjam
        End Get
        Set(value As Date)
            tgl_pinjam = value
        End Set
    End Property

    Public Property TglKembali() As Date
        Get
            Return tgl_kembali
        End Get
        Set(value As Date)
            tgl_kembali = value
        End Set
    End Property

    Public Property KodePelanggan() As String
        Get
            Return kode_pelanggan
        End Get
        Set(value As String)
            kode_pelanggan = value
        End Set
    End Property



    Public Property BayarPelanggan() As String
        Get
            Return bayar
        End Get
        Set(value As String)
            bayar = value
        End Set
    End Property

    Public Property StatusPinjam() As String
        Get
            Return status_pinjam
        End Get
        Set(value As String)
            status_pinjam = value
        End Set
    End Property
End Class
