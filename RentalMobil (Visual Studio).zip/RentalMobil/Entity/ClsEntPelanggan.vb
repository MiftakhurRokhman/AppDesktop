﻿Public Class ClsEntPelanggan
    Private kode_pelanggan As String
    Private nomor_ktp As String
    Private nama_pelanggan As String
    Private alamat As String
    Private jenis_kelamin As String
    Private telepon As String

    Public Property KodePelanggan() As String
        Get
            Return kode_pelanggan
        End Get
        Set(value As String)
            kode_pelanggan = value
        End Set
    End Property

    Public Property NomorKtp() As String
        Get
            Return nomor_ktp
        End Get
        Set(value As String)
            nomor_ktp = value
        End Set
    End Property

    Public Property NamaPelanggan() As String
        Get
            Return nama_pelanggan
        End Get
        Set(value As String)
            nama_pelanggan = value
        End Set
    End Property

    Public Property AlamatPelanggan() As String
        Get
            Return alamat
        End Get
        Set(value As String)
            alamat = value
        End Set
    End Property

    Public Property JenisKelamin() As String
        Get
            Return jenis_kelamin
        End Get
        Set(value As String)
            jenis_kelamin = value
        End Set
    End Property

    Public Property TeleponPelanggan() As String
        Get
            Return telepon
        End Get
        Set(value As String)
            telepon = value
        End Set
    End Property
End Class
