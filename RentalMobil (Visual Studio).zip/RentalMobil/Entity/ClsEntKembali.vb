﻿Public Class ClsEntKembali
    Private kode_denda As String
    Private kode_pinjam As String
    Private terlambat As String
    Private catatan As String
    Private tglkembali As Date
    Private denda As String
    Private total_bayar As String

    Public Property KodeDenda() As String
        Get
            Return kode_denda
        End Get
        Set(value As String)
            kode_denda = value
        End Set
    End Property

    Public Property KodePinjam() As String
        Get
            Return kode_pinjam
        End Get
        Set(value As String)
            kode_pinjam = value
        End Set
    End Property

    Public Property TerlambatDenda() As String
        Get
            Return terlambat
        End Get
        Set(value As String)
            terlambat = value
        End Set
    End Property

    Public Property CatatanDenda() As String
        Get
            Return catatan
        End Get
        Set(value As String)
            catatan = value
        End Set
    End Property

    Public Property Dendaharga() As String
        Get
            Return denda
        End Get
        Set(value As String)
            denda = value
        End Set
    End Property

    Public Property TotalBayar() As String
        Get
            Return total_bayar
        End Get
        Set(value As String)
            total_bayar = value
        End Set
    End Property

    Public Property Tgl_Kembali() As Date
        Get
            Return tglkembali
        End Get
        Set(value As Date)
            tglkembali = value
        End Set
    End Property
End Class
