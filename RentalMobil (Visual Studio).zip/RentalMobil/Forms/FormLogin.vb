﻿Imports System.Data.OleDb

Public Class FormLogin
    Public nama As String
    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtusername.Select()
    End Sub

    Private Sub txtpassword_TextChanged(sender As Object, e As EventArgs) Handles txtpassword.TextChanged
        txtpassword.PasswordChar = "*"
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Dim query As String


        BUKAKONEKSI()
        query = "SELECT * FROM admin WHERE kode_admin = '" & txtusername.Text & "' AND password_admin = '" & txtpassword.Text & "'"
        CMD = New OleDbCommand(query, BUKAKONEKSI)
        CMD.ExecuteNonQuery()
        DTR = CMD.ExecuteReader()

        Dim count As Integer
        count = 0

        While DTR.Read
            count = count + 1
        End While

        If count = 1 Then
            MessageBox.Show("Login Sukses")
            nama = txtusername.Text
            MenuUtama.Show()
            Me.Hide()
        ElseIf count > 1 Then
            MessageBox.Show("Double")
        Else
            MessageBox.Show("Login Gagal")
        End If
    End Sub
End Class
