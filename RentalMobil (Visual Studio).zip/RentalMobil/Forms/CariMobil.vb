﻿Public Class CariMobil
    Dim modeProses As Integer
    Dim baris As Integer
    Private Sub CariMobil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefreshGrid()
    End Sub

    Private Sub RefreshGrid()
        DTGrid = KontrolMobil.TampilData1.ToTable
        DGMobil.DataSource = DTGrid

        If DTGrid.Rows.Count > 0 Then
            baris = DTGrid.Rows.Count - 1
            DGMobil.Rows(DTGrid.Rows.Count - 1).Selected = True
            DGMobil.CurrentCell = DGMobil.Item(1, baris)

        End If
    End Sub

    Private Sub Isibox(br As Integer)

        If br < DTGrid.Rows.Count Then
            With DGMobil.Rows(br)
                Pinjam.txtkdmobil.Text = .Cells(0).Value.ToString
                Pinjam.txtnokendaraan.Text = .Cells(2).Value.ToString
                Pinjam.txtmerkmobil.Text = .Cells(1).Value.ToString
                Pinjam.txtHarga.Text = .Cells(4).Value.ToString
            End With
        End If
    End Sub

    Private Sub DGMobil_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGMobil.CellDoubleClick
        DTGrid = KontrolMobil.TampilData1.ToTable
        baris = e.RowIndex
        DGMobil.Rows(baris).Selected = True
        Isibox(baris)
        Me.Visible = False
    End Sub
End Class