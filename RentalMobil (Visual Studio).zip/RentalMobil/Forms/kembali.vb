﻿Imports System.Data.OleDb

Public Class Kembali
    Dim modeproses As Integer
    Dim baris As Integer
    Private Sub Kembali_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MdiParent = MenuUtama
        txtkdpinjam.Enabled = False
        tgldeadline.Enabled = False
        txtmobil.Enabled = False
        txtnamapeminjam.Enabled = False
        ' txtharga.Enabled = False

        hargadenda.Enabled = False
        ' txthargasewa.Enabled = False
        GroupBox1.Enabled = False
        btnsimpan.Enabled = False
        btnBatal.Enabled = False
        txtkdmobil.Enabled = False
        RefreshGrid()
    End Sub

    Private Sub RefreshGrid()
        DTGrid = KontrolKembali.TampilData.ToTable
        DGKembali.DataSource = DTGrid
        If DTGrid.Rows.Count > 0 Then
            baris = DTGrid.Rows.Count - 1
            DGKembali.Rows(DTGrid.Rows.Count - 1).Selected = True
            DGKembali.CurrentCell = DGKembali.Item(1, baris)
            'AturButton(True)
            'IsiBox(baris)

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CariTransaksi.Visible = True


    End Sub

    Private Sub tglkembali_ValueChanged(sender As Object, e As EventArgs) Handles tglkembali.ValueChanged
        If tglkembali.Value < tgldeadline.Value Then
            tglkembali.Value = tgldeadline.Value
        Else
            lblhari.Text = DateDiff(DateInterval.Day, CDate(tgldeadline.Text), CDate(tglkembali.Text))
        End If




    End Sub

    Private Sub tgldeadline_ValueChanged(sender As Object, e As EventArgs) Handles tgldeadline.ValueChanged
        If tgldeadline.Value > tglkembali.Value Then
            tgldeadline.Value = tglkembali.Value
        Else
            lblhari.Text = DateDiff(DateInterval.Day, CDate(tgldeadline.Text), CDate(tglkembali.Text))
        End If
    End Sub


    Private Sub btnsimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click

        Dim Date2 As Date


        Date2 = Format(tglkembali.Value, "MM/dd/yyyy")

        With EntitasKembali
            .KodeDenda = txtkdkembali.Text
            .KodePinjam = txtkdpinjam.Text
            .Tgl_Kembali = Date2
            .TerlambatDenda = lblhari.Text
            .CatatanDenda = txtcatatan.Text
            .Dendaharga = hargadenda.Text
            .TotalBayar = txthargabaru.Text
        End With

        With EntitasPinjam
            .StatusPinjam = "Kembali"
            .KodePinjam = txtkdpinjam.Text
        End With

        With EntitasMobil
            .StatusMobil = "Tersedia"
            .KodeMobil = txtkdmobil.Text
        End With

        If modeproses = 1 Then
            KontrolKembali.InsertData(EntitasKembali)
            KontrolKembali.updatestatus(EntitasPinjam)
            KontrolKembali.updatemobil(EntitasMobil)

        ElseIf modeproses = 2 Then
            KontrolKembali.UpdateData(EntitasKembali)

        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "INFORMASI")
        RefreshGrid()
        modeproses = 0
    End Sub

    Private Sub btntambah_Click(sender As Object, e As EventArgs) Handles btntambah.Click
        btnsimpan.Enabled = True
        modeproses = 1
        txtkdkembali.Text = KontrolKembali.kodeBaru()
        GroupBox1.Enabled = True
        btnBatal.Enabled = True
        btntambah.Enabled = False
        btnBatal.Enabled = True
        btnhapus.Enabled = False
        BtnTutup.Enabled = False
        btnubah.Enabled = False

        txtkdpinjam.Text = ""
        txtkdmobil.Text = ""
        txtmobil.Text = ""
        txtnamapeminjam.Text = ""
        tgldeadline.Text = ""
        tglkembali.Text = ""
        txthargabaru.Text = ""
        txtcatatan.Text = ""

    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        RefreshGrid()
        modeproses = 0
        GroupBox1.Enabled = False
        btnsimpan.Enabled = False
        btntambah.Enabled = True
        btnBatal.Enabled = False
        btnhapus.Enabled = True
        BtnTutup.Enabled = True
        btnubah.Enabled = True
        txtkdpinjam.Text = ""
        txtkdmobil.Text = ""
        txtmobil.Text = ""
        txtnamapeminjam.Text = ""
        tgldeadline.Text = ""
        tglkembali.Text = ""
        txthargabaru.Text = ""
        txtcatatan.Text = ""
    End Sub

    Private Sub BtnTutup_Click(sender As Object, e As EventArgs) Handles BtnTutup.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim pilih As String = txtkdmobil.Text
        Dim pilih2 As String = txtkdpinjam.Text
        Dim query As String
        Dim hargamobil As Integer
        Dim hargasewa As Integer

        'membaca database pelanggan
        BUKAKONEKSI()
        query = "select * from mobil " & " where kode_mobil ='" & pilih & "'"
        CMD = New OleDbCommand(query, BUKAKONEKSI)
        CMD.ExecuteNonQuery()
        DTR = CMD.ExecuteReader()

        If DTR.HasRows Then
            While DTR.Read()
                hargamobil = DTR("TARIF_MOBIL")
            End While
        End If
        TUTUPKONEKSI()

        BUKAKONEKSI()
        query = "select * from pinjam " & " where kode_pinjam ='" & pilih2 & "'"
        CMD = New OleDbCommand(query, BUKAKONEKSI)
        CMD.ExecuteNonQuery()
        DTR = CMD.ExecuteReader()

        If DTR.HasRows Then
            While DTR.Read()
                hargasewa = DTR("BAYAR")
            End While
        End If
        TUTUPKONEKSI()

        Dim jumlah As Integer
        Dim denda As Integer
        Dim harga As Integer
        Dim harga1 As Integer
        Dim hargabaru As Integer
        Dim hari As Integer

        harga = hargamobil
        hari = lblhari.Text
        'txthargamobil.Text = harga
        harga1 = hargasewa

        denda = (0.2 * harga) * hari
        hargadenda.Text = denda

        hargabaru = denda + harga1
        'txthargabaru.Text = hargabaru

        jumlah = hargabaru + (hari * harga)
        txthargabaru.Text = jumlah
    End Sub

    Private Sub btnhapus_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolKembali.cekKembaliDireferensi(txtkdkembali.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "PERINGATAN")
            Exit Sub
        End If

        If MsgBox("Apakah anda yakin akan menghapus" & txtkdkembali.Text & "?",
            MsgBoxStyle.Question + MsgBoxStyle.YesNo, "KONFIRMASI") = MsgBoxResult.Yes Then
            KontrolKembali.DeleteData(txtkdkembali.Text)
        End If
        RefreshGrid()
    End Sub
    Private Sub DGKembali_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGKembali.CellClick
        If modeproses = 0 Then
            baris = e.RowIndex
            DGKembali.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub

    Private Sub IsiBox(br As Integer)
        If br < DTGrid.Rows.Count Then
            With DGKembali.Rows(br)
                txtkdkembali.Text = .Cells(0).Value.ToString
                txtkdpinjam.Text = .Cells(1).Value.ToString
                txtkdmobil.Text = .Cells(2).Value.ToString
                txtmobil.Text = .Cells(3).Value.ToString
                txtnamapeminjam.Text = .Cells(5).Value.ToString
                tgldeadline.Text = .Cells(9).Value.ToString
                tglkembali.Text = .Cells(10).Value.ToString
                txthargabaru.Text = .Cells(14).Value.ToString
                txtcatatan.Text = .Cells(16).Value.ToString
            End With

        End If
    End Sub

    Private Sub btnubah_Click(sender As Object, e As EventArgs) Handles btnubah.Click
        btnsimpan.Enabled = True
        modeproses = 2
        GroupBox1.Enabled = True
        Button1.Enabled = False
        btnBatal.Enabled = True
        btnBatal.Enabled = True
        btntambah.Enabled = False
        btnubah.Enabled = False
        btnhapus.Enabled = False
        BtnTutup.Enabled = False
        txtcatatan.Enabled = True
        tglkembali.Enabled = True
    End Sub
End Class