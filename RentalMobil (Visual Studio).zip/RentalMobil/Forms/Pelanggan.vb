﻿Public Class Pelanggan

    Dim modeproses As Integer
    Dim baris As Integer

    Private Sub User_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MdiParent = MenuUtama
        txtkdpengguna.Enabled = False
        RefreshGrid()
        cmbjenkel.Items.Add("Laki-Laki")
        cmbjenkel.Items.Add("Perempuan")
    End Sub

    Private Sub RefreshGrid()
        DTGrid = KontrolPelanggan.TampilData.ToTable
        DGPelanggan.DataSource = DTGrid
        If DTGrid.Rows.Count > 0 Then
            baris = DTGrid.Rows.Count - 1
            DGPelanggan.Rows(DTGrid.Rows.Count - 1).Selected = True
            DGPelanggan.CurrentCell = DGPelanggan.Item(1, baris)
            AturButton(True)
            IsiBox(baris)
        End If
    End Sub

    Private Sub IsiBox(br As Integer)
        If br < DTGrid.Rows.Count Then
            With DGPelanggan.Rows(br)
                txtkdpengguna.Text = .Cells(0).Value.ToString
                txtnoktp.Text = .Cells(1).Value.ToString
                txtnamapengguna.Text = .Cells(2).Value.ToString
                txtAlamat.Text = .Cells(3).Value.ToString
                cmbjenkel.Text = .Cells(4).Value.ToString
                txttelepon.Text = .Cells(5).Value.ToString
            End With
            LblBaris.Text = "Data ke-" & br + 1 & " dari " & DGPelanggan.RowCount - 1 & " data"
        End If
    End Sub

    Private Sub AturButton(st As Boolean)
        btntambah.Enabled = st
        btnhapus.Enabled = st
        btnubah.Enabled = st
        btnBatal.Enabled = Not st
        btnsimpan.Enabled = Not st
        BtnTutup.Enabled = st

        GroupBox1.Enabled = Not st
        GroupBox2.Enabled = st
    End Sub

    Private Sub BtnTambah_Click(sender As Object, e As EventArgs) Handles btntambah.Click
        AturButton(False)
        modeproses = 1
        txtnamapengguna.Text = ""
        txtnoktp.Text = ""
        txtnamapengguna.Text = ""
        txtAlamat.Text = ""
        cmbjenkel.Text = ""
        txttelepon.Text = ""
        txtkdpengguna.Text = KontrolPelanggan.kodeBaru()

        GroupBox2.Enabled = True
        BtnTutup.Enabled = False

    End Sub

    Private Sub BtnHapus_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolPelanggan.cekPelangganDireferensi(txtkdpengguna.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "PERINGATAN")
            Exit Sub
        End If

        If MsgBox("Apakah anda yakin akan menghapus" & txtkdpengguna.Text & "-" & txtnamapengguna.Text & "?",
            MsgBoxStyle.Question + MsgBoxStyle.YesNo, "KONFIRMASI") = MsgBoxResult.Yes Then
            KontrolPelanggan.DeleteData(txtkdpengguna.Text)
        End If
        RefreshGrid()

    End Sub

    Private Sub BtnUbah_Click(sender As Object, e As EventArgs) Handles btnubah.Click
        AturButton(False)
        txtnamapengguna.Focus()
        modeproses = 2

        GroupBox2.Enabled = True
        BtnTutup.Enabled = False
    End Sub

    Private Sub BtnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        RefreshGrid()
        AturButton(True)
        modeproses = 0

    End Sub
    Private Sub Btntutup_Click(sender As Object, e As EventArgs) Handles BtnTutup.Click
        Me.Close()
    End Sub

    Private Sub DGPelanggan_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGPelanggan.CellClick
        If modeproses = 0 Then
            baris = e.RowIndex
            DGPelanggan.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub
    Private Sub BtnSimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        With EntitiasPelanggan
            .KodePelanggan = txtkdpengguna.Text
            .NomorKtp = txtnoktp.Text
            .NamaPelanggan = txtnamapengguna.Text
            .AlamatPelanggan = txtAlamat.Text
            .JenisKelamin = cmbjenkel.Text
            .TeleponPelanggan = txttelepon.Text
        End With

        If modeproses = 1 Then
            KontrolPelanggan.InsertData(EntitiasPelanggan)

        ElseIf modeproses = 2 Then
            KontrolPelanggan.updateData(EntitiasPelanggan)

        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "INFORMASI")
        RefreshGrid()
        modeproses = 0
    End Sub


End Class