﻿Imports System.Data.OleDb

Public Class Mobil
    Dim modeproses As Integer
    Dim baris As Integer

    Private Sub Mobil_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Dim query As String
        Me.MdiParent = MenuUtama
        txtkdmobil.Enabled = False
        RefreshGrid()
        'CmbStatus.Enabled = False
        CmbStatus.Items.Add("Tersedia")
        CmbStatus.Items.Add("Digunakan")

    End Sub



    Private Sub AturButton(st As Boolean)
        btntambah.Enabled = st
        btnhapus.Enabled = st
        btnubah.Enabled = st
        btnBatal.Enabled = Not st
        btnsimpan.Enabled = Not st
        BtnTutup.Enabled = st

        GroupBox1.Enabled = Not st
        GroupBox2.Enabled = st
    End Sub

    Private Sub IsiBox(br As Integer)
        If br < DTGrid.Rows.Count Then
            With DGMobil.Rows(br)
                txtkdmobil.Text = .Cells(0).Value.ToString
                txtMerk.Text = .Cells(1).Value.ToString
                txtnokendaraan.Text = .Cells(2).Value.ToString
                txtWarna.Text = .Cells(3).Value.ToString
                txttarifmobil.Text = .Cells(4).Value.ToString
                txtTahun.Text = .Cells(5).Value.ToString
                CmbStatus.Text = .Cells(6).Value.ToString
            End With
            LblBaris.Text = "Data ke-" & br + 1 & " dari " & DGMobil.RowCount - 1 & " data"
        End If
    End Sub

    Private Sub RefreshGrid()
        DTGrid = KontrolMobil.TampilData.ToTable
        DGMobil.DataSource = DTGrid
        If DTGrid.Rows.Count > 0 Then
            baris = DTGrid.Rows.Count - 1
            DGMobil.Rows(DTGrid.Rows.Count - 1).Selected = True
            DGMobil.CurrentCell = DGMobil.Item(1, baris)
            AturButton(True)
            IsiBox(baris)
        End If
    End Sub
    Private Sub BtnTambah_Click(sender As Object, e As EventArgs) Handles btntambah.Click
        AturButton(False)
        modeproses = 1
        txtMerk.Text = ""
        txtnokendaraan.Text = ""
        txtWarna.Text = ""
        txttarifmobil.Text = ""
        txtTahun.Text = ""
        txtkdmobil.Text = KontrolMobil.kodeBaru()

        GroupBox2.Enabled = True
        BtnTutup.Enabled = False

    End Sub
    Private Sub BtnHapus_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolMobil.cekMobilDireferensi(txtkdmobil.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "PERINGATAN")
            Exit Sub
        End If

        If MsgBox("Apakah anda yakin akan menghapus" & txtkdmobil.Text & "-" & txtMerk.Text & "?",
            MsgBoxStyle.Question + MsgBoxStyle.YesNo, "KONFIRMASI") = MsgBoxResult.Yes Then
            KontrolMobil.DeleteData(txtkdmobil.Text)
        End If
        RefreshGrid()

    End Sub
    Private Sub BtnUbah_Click(sender As Object, e As EventArgs) Handles btnubah.Click
        AturButton(False)
        txtMerk.Focus()
        modeproses = 2

        GroupBox2.Enabled = True
        BtnTutup.Enabled = False
    End Sub

    Private Sub BtnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        RefreshGrid()
        AturButton(True)
        modeproses = 0

    End Sub
    Private Sub Btntutup_Click(sender As Object, e As EventArgs) Handles BtnTutup.Click
        Me.Close()
    End Sub

    Private Sub DGMobil_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGMobil.CellClick
        If modeproses = 0 Then
            baris = e.RowIndex
            DGMobil.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub
    Private Sub BtnSimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        With EntitasMobil
            .KodeMobil = txtkdmobil.Text
            .MerkMobil = txtMerk.Text
            .NomorKendaraan = txtnokendaraan.Text
            .Warnamobil = txtWarna.Text
            .TarifMobil = txttarifmobil.Text
            .TahunMobil = txtTahun.Text
            .StatusMobil = CmbStatus.Text
        End With

        If modeproses = 1 Then
            KontrolMobil.InsertData(EntitasMobil)

        ElseIf modeproses = 2 Then
            KontrolMobil.updateData(EntitasMobil)

        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "INFORMASI")
        RefreshGrid()
        modeproses = 0
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

End Class