﻿Imports System.Data.OleDb
Public Class Pinjam
    Dim modeProses As Integer
    Dim baris As Integer


    Private Sub Pinjam_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MdiParent = MenuUtama
        Dim kdadmin As String

        '=============================================================='
        'kalo error disini sesuaikan sama format tgl di komputer'
        tglkembali.Format = DateTimePickerFormat.Custom
        tglkembali.CustomFormat = "MM/dd/yyyy"
        tglpinjam.Format = DateTimePickerFormat.Custom
        tglpinjam.CustomFormat = "MM/dd/yyyy"
        '=============================================================='



        'memanggil kode admin pada form login
        kdadmin = FormLogin.nama
        'memasukkan kode admin ke dalam texbox kode admin
        txtkdadmin.Text = kdadmin


        'disable textbox agar tidak bisa dirubah
        txtkdpelanggan.Enabled = False
        txtkdadmin.Enabled = False
        txtkdpinjam.Enabled = False
        txtalamat.Enabled = False
        txttelepon.Enabled = False
        txtkdmobil.Enabled = False
        txtpinjam.Enabled = False
        txtnokendaraan.Enabled = False
        txtHarga.Enabled = False
        txtTotal.Enabled = False

        'memberikan nilai pada combobox status pinjam
        txtpinjam.Text = "Pinjam"

        'refresh tabel pinjam
        RefreshGrid()
        Dim query As String

        'menampilkan data dari database pelanggan ke combobox namapelanggan
        BUKAKONEKSI()
        query = "select * from pelanggan"
        CMD = New OleDbCommand(query, BUKAKONEKSI)
        DTR = CMD.ExecuteReader()

        If DTR.HasRows Then
            While DTR.Read()
                'menampilkan data nama pengguna dari database pelanggan
                CmbPelanggan.Items.Add(DTR("nama_pengguna"))
            End While
        End If
        TUTUPKONEKSI()

    End Sub

    'membuat fungsi tombol yang aktif dan tidak aktif
    Private Sub AturButton(st As Boolean)
        btntambah.Enabled = st
        btnubah.Enabled = st
        btnhapus.Enabled = st
        btnBatal.Enabled = Not st
        btnsimpan.Enabled = Not st
        BtnTutup.Enabled = st

        GroupBox1.Enabled = Not st
        GroupBox2.Enabled = st
    End Sub


    'fungsi untuk menampilkan kode pelanggan,alamat,telepon ke texbox berdasarkan combobox yang dipilih pada nama pelanggan
    Private Sub cmbPelanggan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbPelanggan.SelectedIndexChanged
        Dim pilih As String = CmbPelanggan.SelectedItem.ToString()
        Dim query As String

        'membaca database pelanggan
        BUKAKONEKSI()
        query = "select * from pelanggan" & " where nama_pengguna='" & pilih & "'"
        CMD = New OleDbCommand(query, BUKAKONEKSI)
        CMD.ExecuteNonQuery()
        DTR = CMD.ExecuteReader()

        If DTR.HasRows Then
            While DTR.Read()
                'memasukkan kode,pelanggan,alamat,telepon ke textbox
                txtkdpelanggan.Text = DTR("kode_pelanggan")
                txtalamat.Text = DTR("alamat")
                txttelepon.Text = DTR("Telepon")
            End While
        End If
    End Sub

    'fungsi button tambah untuk membuat textbox menjadi bersih
    Private Sub BtnTambah_Click(sender As Object, e As EventArgs) Handles btntambah.Click
        AturButton(False)
        modeProses = 1
        txtkdmobil.Text = ""
        txtnokendaraan.Text = ""
        txtmerkmobil.Text = ""
        txtkdpelanggan.Text = ""
        CmbPelanggan.Text = ""
        txtalamat.Text = ""
        txttelepon.Text = ""
        'tglkembali.Text = ""
        'tglpinjam.Text = ""
        'fungsi kode baru dnegan memanggil kontrol pinjam dengan fungsi kodebaru
        txtkdpinjam.Text = KontrolPinjam.kodeBaru()


        btnsimpan.Enabled = True

        btnBatal.Enabled = True
        GroupBox2.Enabled = True

    End Sub


    Private Sub DGPinjam_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGPinjam.CellClick
        If modeProses = 0 Then
            baris = e.RowIndex
            DGPinjam.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub

    Private Sub IsiBox(br As Integer)
        If br < DTGrid.Rows.Count Then
            With DGPinjam.Rows(br)
                txtkdpinjam.Text = .Cells(0).Value.ToString
                txtkdadmin.Text = .Cells(1).Value.ToString
                txtkdmobil.Text = .Cells(2).Value.ToString
                txtmerkmobil.Text = .Cells(3).Value.ToString
                txtnokendaraan.Text = .Cells(4).Value.ToString
                txtkdpelanggan.Text = .Cells(5).Value.ToString
                CmbPelanggan.Text = .Cells(6).Value.ToString
                txtalamat.Text = .Cells(7).Value.ToString
                txttelepon.Text = .Cells(8).Value.ToString
                tglpinjam.Value = .Cells(9).Value.ToString
                tglkembali.Value = .Cells(10).Value.ToString
                txtHarga.Text = .Cells(13).Value.ToString


            End With
            LblBaris.Text = "Data ke-" & br + 1 & " dari " & DGPinjam.RowCount - 1 & " data"
        End If
    End Sub

    Private Sub BtnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        RefreshGrid()
        AturButton(True)
        modeProses = 0

    End Sub

    ' button simpan untuk menyimpan data
    Private Sub BtnSimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        Dim Date1 As Date
        Dim Date2 As Date
        '=============================================================='
        'kalo error disini sesuaikan sama format tgl di komputer'
        Date1 = Format(tglpinjam.Value, "MM/dd/yyyy")
        Date2 = Format(tglkembali.Value, "MM/dd/yyyy")
        '=============================================================='


        With EntitasPinjam
            .BayarPelanggan = txtTotal.Text
            .KodeAdmin = txtkdadmin.Text
            .KodeMobil = txtkdmobil.Text
            .KodePelanggan = txtkdpelanggan.Text
            .KodePinjam = txtkdpinjam.Text
            .StatusPinjam = txtpinjam.Text
            .TglKembali = Date2
            .TglPinjam = Date1

        End With

        With EntitasMobil
            .StatusMobil = "Digunakan"
            .KodeMobil = txtkdmobil.Text
        End With

        If modeProses = 1 Then
            KontrolPinjam.InsertData(EntitasPinjam)
            KontrolKembali.updatemobil(EntitasMobil)

            txtkdmobil.Text = ""
            txtmerkmobil.Text = ""
            txtnokendaraan.Text = ""
            txtkdpelanggan.Text = ""
            CmbPelanggan.Text = ""
            txtalamat.Text = ""
            txttelepon.Text = ""
            tglpinjam.Text = ""
            tglkembali.Text = ""

            txtsisabayar.Text = ""
            txtTotal.Text = ""


        ElseIf modeProses = 2 Then
            KontrolPinjam.updateData(EntitasPinjam)

        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "INFORMASI")
        RefreshGrid()
        modeProses = 0
    End Sub




    'fungsi refresh grid
    Private Sub RefreshGrid()
        DTGrid = KontrolPinjam.TampilData.ToTable
        DGPinjam.DataSource = DTGrid
        If DTGrid.Rows.Count > 0 Then
            baris = DTGrid.Rows.Count - 1
            DGPinjam.DataSource = DTGrid
            DGPinjam.Rows(DTGrid.Rows.Count - 1).Selected = True
            DGPinjam.CurrentCell = DGPinjam.Item(1, baris)
            AturButton(True)
        End If
    End Sub

    'perhitngan selisih tanggal pada text tgl pinjam
    Private Sub tglpinjam_ValueChanged(sender As Object, e As EventArgs) Handles tglpinjam.ValueChanged
        If tglpinjam.Value > tglkembali.Value Then
            tglpinjam.Value = tglkembali.Value
        Else
            LblSelisih.Text = DateDiff(DateInterval.Day, CDate(tglpinjam.Text), CDate(tglkembali.Text))
        End If
    End Sub

    'perhitngan selisih tanggal pada text tgl kembali
    Private Sub tglkembali_ValueChanged(sender As Object, e As EventArgs) Handles tglkembali.ValueChanged
        If tglkembali.Value < tglpinjam.Value Then
            tglkembali.Value = tglpinjam.Value
        Else
            LblSelisih.Text = DateDiff(DateInterval.Day, CDate(tglpinjam.Text), CDate(tglkembali.Text))
        End If


    End Sub



    'perhitungan jumlah sisa pembayaran
    Private Sub Bayar_TextChanged(sender As Object, e As EventArgs) Handles Bayar.TextChanged
        Dim sisa As Integer
        Dim jumlah As Integer
        Dim bayar1 As Integer

        jumlah = txtTotal.Text
        bayar1 = Bayar.Text

        sisa = bayar1 - jumlah
        txtsisabayar.Text = sisa
    End Sub

    Private Sub btnubah_Click_1(sender As Object, e As EventArgs) Handles btnubah.Click
        AturButton(False)
        txtmerkmobil.Select()
        modeProses = 2

        GroupBox2.Enabled = True
        BtnTutup.Enabled = False
    End Sub

    Private Sub btnhapus_Click_1(sender As Object, e As EventArgs) Handles btnhapus.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolPinjam.cekPelangganDireferensi(txtkdpinjam.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "PERINGATAN")
            Exit Sub
        End If

        If MsgBox("Apakah anda yakin akan menghapus" & txtkdpinjam.Text & "?",
            MsgBoxStyle.Question + MsgBoxStyle.YesNo, "KONFIRMASI") = MsgBoxResult.Yes Then
            KontrolPinjam.DeleteData(txtkdpinjam.Text)
        End If
        RefreshGrid()
    End Sub

    Private Sub BtnTutup_Click(sender As Object, e As EventArgs) Handles BtnTutup.Click
        Me.Close()
    End Sub

    Private Sub btnmobil_Click(sender As Object, e As EventArgs) Handles btnmobil.Click
        CariMobil.Visible = True
    End Sub

    Private Sub btnhitung_Click(sender As Object, e As EventArgs) Handles btnhitung.Click

        'perhitungan jumlah harga mobil dikali jarak pada hari
        Dim jumlah As Integer
        Dim harga As Integer
        Dim jarak As Integer


        'harga = txtHarga.Text
        harga = txtHarga.Text
        jarak = LblSelisih.Text

        jumlah = harga * jarak

        txtTotal.Text = jumlah
    End Sub


End Class