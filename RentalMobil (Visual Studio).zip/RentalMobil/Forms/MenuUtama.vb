﻿Public Class MenuUtama
    Private Sub MenuUtama_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub OlahDataMobilToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OlahDataMobilToolStripMenuItem.Click
        Mobil.Show()
    End Sub

    Private Sub TransaksiBaruToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TransaksiBaruToolStripMenuItem.Click
        Pinjam.Show()
    End Sub

    Private Sub PengembalianToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PengembalianToolStripMenuItem.Click
        Kembali.Show()
    End Sub

    Private Sub OlahDataPelangganToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OlahDataPelangganToolStripMenuItem.Click
        Pelanggan.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class