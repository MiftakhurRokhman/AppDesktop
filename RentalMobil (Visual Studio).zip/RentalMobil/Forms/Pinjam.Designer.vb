﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pinjam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DGPinjam = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnhitung = New System.Windows.Forms.Button()
        Me.btnmobil = New System.Windows.Forms.Button()
        Me.txtmerkmobil = New System.Windows.Forms.TextBox()
        Me.txtpinjam = New System.Windows.Forms.TextBox()
        Me.txtHarga = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Bayar = New System.Windows.Forms.TextBox()
        Me.LblSelisih = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CmbPelanggan = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtnokendaraan = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtkdmobil = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tglpinjam = New System.Windows.Forms.DateTimePicker()
        Me.txtkdadmin = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txttelepon = New System.Windows.Forms.TextBox()
        Me.txtalamat = New System.Windows.Forms.TextBox()
        Me.txtkdpelanggan = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtsisabayar = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tglkembali = New System.Windows.Forms.DateTimePicker()
        Me.txtkdpinjam = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.kdpinjam = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnhapus = New System.Windows.Forms.Button()
        Me.btnubah = New System.Windows.Forms.Button()
        Me.btntambah = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.BtnTutup = New System.Windows.Forms.Button()
        Me.LblBaris = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        CType(Me.DGPinjam, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'DGPinjam
        '
        Me.DGPinjam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGPinjam.Location = New System.Drawing.Point(22, 464)
        Me.DGPinjam.Margin = New System.Windows.Forms.Padding(2)
        Me.DGPinjam.Name = "DGPinjam"
        Me.DGPinjam.RowTemplate.Height = 24
        Me.DGPinjam.Size = New System.Drawing.Size(684, 160)
        Me.DGPinjam.TabIndex = 39
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnhitung)
        Me.GroupBox1.Controls.Add(Me.btnmobil)
        Me.GroupBox1.Controls.Add(Me.txtmerkmobil)
        Me.GroupBox1.Controls.Add(Me.txtpinjam)
        Me.GroupBox1.Controls.Add(Me.txtHarga)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Bayar)
        Me.GroupBox1.Controls.Add(Me.LblSelisih)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.CmbPelanggan)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtnokendaraan)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtkdmobil)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.tglpinjam)
        Me.GroupBox1.Controls.Add(Me.txtkdadmin)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txttelepon)
        Me.GroupBox1.Controls.Add(Me.txtalamat)
        Me.GroupBox1.Controls.Add(Me.txtkdpelanggan)
        Me.GroupBox1.Controls.Add(Me.txtTotal)
        Me.GroupBox1.Controls.Add(Me.txtsisabayar)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.tglkembali)
        Me.GroupBox1.Controls.Add(Me.txtkdpinjam)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.kdpinjam)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 55)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(683, 292)
        Me.GroupBox1.TabIndex = 53
        Me.GroupBox1.TabStop = False
        '
        'btnhitung
        '
        Me.btnhitung.Location = New System.Drawing.Point(586, 162)
        Me.btnhitung.Name = "btnhitung"
        Me.btnhitung.Size = New System.Drawing.Size(70, 23)
        Me.btnhitung.TabIndex = 91
        Me.btnhitung.Text = "Total"
        Me.btnhitung.UseVisualStyleBackColor = True
        '
        'btnmobil
        '
        Me.btnmobil.Location = New System.Drawing.Point(254, 142)
        Me.btnmobil.Name = "btnmobil"
        Me.btnmobil.Size = New System.Drawing.Size(29, 23)
        Me.btnmobil.TabIndex = 90
        Me.btnmobil.Text = "."
        Me.btnmobil.UseVisualStyleBackColor = True
        '
        'txtmerkmobil
        '
        Me.txtmerkmobil.Location = New System.Drawing.Point(161, 143)
        Me.txtmerkmobil.Margin = New System.Windows.Forms.Padding(2)
        Me.txtmerkmobil.Name = "txtmerkmobil"
        Me.txtmerkmobil.Size = New System.Drawing.Size(89, 20)
        Me.txtmerkmobil.TabIndex = 89
        '
        'txtpinjam
        '
        Me.txtpinjam.Location = New System.Drawing.Point(413, 137)
        Me.txtpinjam.Margin = New System.Windows.Forms.Padding(2)
        Me.txtpinjam.Name = "txtpinjam"
        Me.txtpinjam.Size = New System.Drawing.Size(243, 20)
        Me.txtpinjam.TabIndex = 88
        '
        'txtHarga
        '
        Me.txtHarga.Location = New System.Drawing.Point(161, 174)
        Me.txtHarga.Margin = New System.Windows.Forms.Padding(2)
        Me.txtHarga.Name = "txtHarga"
        Me.txtHarga.Size = New System.Drawing.Size(122, 20)
        Me.txtHarga.TabIndex = 87
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(28, 177)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 86
        Me.Label6.Text = "Harga"
        '
        'Bayar
        '
        Me.Bayar.Location = New System.Drawing.Point(534, 223)
        Me.Bayar.Margin = New System.Windows.Forms.Padding(2)
        Me.Bayar.Name = "Bayar"
        Me.Bayar.Size = New System.Drawing.Size(122, 20)
        Me.Bayar.TabIndex = 85
        '
        'LblSelisih
        '
        Me.LblSelisih.AutoSize = True
        Me.LblSelisih.Location = New System.Drawing.Point(161, 260)
        Me.LblSelisih.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblSelisih.Name = "LblSelisih"
        Me.LblSelisih.Size = New System.Drawing.Size(13, 13)
        Me.LblSelisih.TabIndex = 84
        Me.LblSelisih.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 260)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 83
        Me.Label1.Text = "Selisih"
        '
        'CmbPelanggan
        '
        Me.CmbPelanggan.FormattingEnabled = True
        Me.CmbPelanggan.Location = New System.Drawing.Point(414, 55)
        Me.CmbPelanggan.Name = "CmbPelanggan"
        Me.CmbPelanggan.Size = New System.Drawing.Size(242, 21)
        Me.CmbPelanggan.TabIndex = 81
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(27, 146)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(59, 13)
        Me.Label14.TabIndex = 79
        Me.Label14.Text = "Merk Mobil"
        '
        'txtnokendaraan
        '
        Me.txtnokendaraan.Location = New System.Drawing.Point(161, 116)
        Me.txtnokendaraan.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnokendaraan.Name = "txtnokendaraan"
        Me.txtnokendaraan.Size = New System.Drawing.Size(122, 20)
        Me.txtnokendaraan.TabIndex = 78
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(27, 118)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 13)
        Me.Label7.TabIndex = 77
        Me.Label7.Text = "Nomor Kendaraan"
        '
        'txtkdmobil
        '
        Me.txtkdmobil.Location = New System.Drawing.Point(161, 89)
        Me.txtkdmobil.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkdmobil.Name = "txtkdmobil"
        Me.txtkdmobil.Size = New System.Drawing.Size(122, 20)
        Me.txtkdmobil.TabIndex = 76
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(408, 198)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 13)
        Me.Label4.TabIndex = 75
        Me.Label4.Text = "Total Biaya"
        '
        'tglpinjam
        '
        Me.tglpinjam.Location = New System.Drawing.Point(161, 200)
        Me.tglpinjam.Margin = New System.Windows.Forms.Padding(2)
        Me.tglpinjam.Name = "tglpinjam"
        Me.tglpinjam.Size = New System.Drawing.Size(122, 20)
        Me.tglpinjam.TabIndex = 74
        '
        'txtkdadmin
        '
        Me.txtkdadmin.Location = New System.Drawing.Point(161, 53)
        Me.txtkdadmin.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkdadmin.Name = "txtkdadmin"
        Me.txtkdadmin.Size = New System.Drawing.Size(122, 20)
        Me.txtkdadmin.TabIndex = 73
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 53)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 13)
        Me.Label3.TabIndex = 72
        Me.Label3.Text = "Kode Admin"
        '
        'txttelepon
        '
        Me.txttelepon.Location = New System.Drawing.Point(413, 105)
        Me.txttelepon.Margin = New System.Windows.Forms.Padding(2)
        Me.txttelepon.Name = "txttelepon"
        Me.txttelepon.Size = New System.Drawing.Size(243, 20)
        Me.txttelepon.TabIndex = 71
        '
        'txtalamat
        '
        Me.txtalamat.Location = New System.Drawing.Point(413, 81)
        Me.txtalamat.Margin = New System.Windows.Forms.Padding(2)
        Me.txtalamat.Name = "txtalamat"
        Me.txtalamat.Size = New System.Drawing.Size(243, 20)
        Me.txtalamat.TabIndex = 70
        '
        'txtkdpelanggan
        '
        Me.txtkdpelanggan.Location = New System.Drawing.Point(413, 30)
        Me.txtkdpelanggan.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkdpelanggan.Name = "txtkdpelanggan"
        Me.txtkdpelanggan.Size = New System.Drawing.Size(243, 20)
        Me.txtkdpelanggan.TabIndex = 68
        '
        'txtTotal
        '
        Me.txtTotal.Location = New System.Drawing.Point(534, 195)
        Me.txtTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(122, 20)
        Me.txtTotal.TabIndex = 67
        '
        'txtsisabayar
        '
        Me.txtsisabayar.Location = New System.Drawing.Point(534, 253)
        Me.txtsisabayar.Margin = New System.Windows.Forms.Padding(2)
        Me.txtsisabayar.Name = "txtsisabayar"
        Me.txtsisabayar.Size = New System.Drawing.Size(122, 20)
        Me.txtsisabayar.TabIndex = 66
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(308, 144)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(71, 13)
        Me.Label16.TabIndex = 64
        Me.Label16.Text = "Status Pinjam"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(410, 253)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(89, 13)
        Me.Label15.TabIndex = 63
        Me.Label15.Text = "Sisa Pembayaran"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(410, 223)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(34, 13)
        Me.Label13.TabIndex = 62
        Me.Label13.Text = "Bayar"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(306, 105)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 13)
        Me.Label12.TabIndex = 61
        Me.Label12.Text = "Telepon"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(306, 78)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(39, 13)
        Me.Label11.TabIndex = 60
        Me.Label11.Text = "Alamat"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(306, 55)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(89, 13)
        Me.Label10.TabIndex = 59
        Me.Label10.Text = "Nama Pelanggan"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(306, 30)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 13)
        Me.Label9.TabIndex = 58
        Me.Label9.Text = "Kode Pelanggan"
        '
        'tglkembali
        '
        Me.tglkembali.Location = New System.Drawing.Point(161, 231)
        Me.tglkembali.Margin = New System.Windows.Forms.Padding(2)
        Me.tglkembali.Name = "tglkembali"
        Me.tglkembali.Size = New System.Drawing.Size(122, 20)
        Me.tglkembali.TabIndex = 57
        '
        'txtkdpinjam
        '
        Me.txtkdpinjam.Location = New System.Drawing.Point(161, 26)
        Me.txtkdpinjam.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkdpinjam.Name = "txtkdpinjam"
        Me.txtkdpinjam.Size = New System.Drawing.Size(122, 20)
        Me.txtkdpinjam.TabIndex = 56
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(27, 231)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(86, 13)
        Me.Label8.TabIndex = 55
        Me.Label8.Text = "Tanggal Kembali"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(27, 89)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "Kode Mobil"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 205)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 53
        Me.Label2.Text = "Tanggal Pinjam"
        '
        'kdpinjam
        '
        Me.kdpinjam.AutoSize = True
        Me.kdpinjam.Location = New System.Drawing.Point(27, 26)
        Me.kdpinjam.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.kdpinjam.Name = "kdpinjam"
        Me.kdpinjam.Size = New System.Drawing.Size(66, 13)
        Me.kdpinjam.TabIndex = 52
        Me.kdpinjam.Text = "Kode Pinjam"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnhapus)
        Me.GroupBox2.Controls.Add(Me.btnubah)
        Me.GroupBox2.Controls.Add(Me.btntambah)
        Me.GroupBox2.Controls.Add(Me.btnBatal)
        Me.GroupBox2.Controls.Add(Me.btnsimpan)
        Me.GroupBox2.Controls.Add(Me.BtnTutup)
        Me.GroupBox2.Location = New System.Drawing.Point(22, 345)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(684, 90)
        Me.GroupBox2.TabIndex = 54
        Me.GroupBox2.TabStop = False
        '
        'btnhapus
        '
        Me.btnhapus.Image = Global.RentalMobil.My.Resources.Resources.hapus2
        Me.btnhapus.Location = New System.Drawing.Point(239, 18)
        Me.btnhapus.Margin = New System.Windows.Forms.Padding(2)
        Me.btnhapus.Name = "btnhapus"
        Me.btnhapus.Size = New System.Drawing.Size(83, 64)
        Me.btnhapus.TabIndex = 46
        Me.btnhapus.Text = "Hapus"
        Me.btnhapus.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnhapus.UseVisualStyleBackColor = True
        '
        'btnubah
        '
        Me.btnubah.Image = Global.RentalMobil.My.Resources.Resources.edit2
        Me.btnubah.Location = New System.Drawing.Point(150, 17)
        Me.btnubah.Margin = New System.Windows.Forms.Padding(2)
        Me.btnubah.Name = "btnubah"
        Me.btnubah.Size = New System.Drawing.Size(75, 64)
        Me.btnubah.TabIndex = 47
        Me.btnubah.Text = "Ubah"
        Me.btnubah.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnubah.UseVisualStyleBackColor = True
        '
        'btntambah
        '
        Me.btntambah.Image = Global.RentalMobil.My.Resources.Resources.tambah1
        Me.btntambah.Location = New System.Drawing.Point(65, 17)
        Me.btntambah.Margin = New System.Windows.Forms.Padding(2)
        Me.btntambah.Name = "btntambah"
        Me.btntambah.Size = New System.Drawing.Size(70, 63)
        Me.btntambah.TabIndex = 45
        Me.btntambah.Text = "Tambah"
        Me.btntambah.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btntambah.UseVisualStyleBackColor = True
        '
        'btnBatal
        '
        Me.btnBatal.Image = Global.RentalMobil.My.Resources.Resources.close2
        Me.btnBatal.Location = New System.Drawing.Point(440, 18)
        Me.btnBatal.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(79, 63)
        Me.btnBatal.TabIndex = 15
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'btnsimpan
        '
        Me.btnsimpan.Image = Global.RentalMobil.My.Resources.Resources.Save21
        Me.btnsimpan.Location = New System.Drawing.Point(338, 18)
        Me.btnsimpan.Margin = New System.Windows.Forms.Padding(2)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(81, 63)
        Me.btnsimpan.TabIndex = 12
        Me.btnsimpan.Text = "Simpan"
        Me.btnsimpan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'BtnTutup
        '
        Me.BtnTutup.Image = Global.RentalMobil.My.Resources.Resources.close2
        Me.BtnTutup.Location = New System.Drawing.Point(534, 18)
        Me.BtnTutup.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnTutup.Name = "BtnTutup"
        Me.BtnTutup.Size = New System.Drawing.Size(83, 63)
        Me.BtnTutup.TabIndex = 44
        Me.BtnTutup.Text = "Tutup"
        Me.BtnTutup.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnTutup.UseVisualStyleBackColor = True
        '
        'LblBaris
        '
        Me.LblBaris.AutoSize = True
        Me.LblBaris.Location = New System.Drawing.Point(309, 442)
        Me.LblBaris.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblBaris.Name = "LblBaris"
        Me.LblBaris.Size = New System.Drawing.Size(108, 13)
        Me.LblBaris.TabIndex = 55
        Me.LblBaris.Text = "Data Ke-0 dari 0 data"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(22, 19)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(162, 24)
        Me.Label17.TabIndex = 96
        Me.Label17.Text = "Data Peminjaman "
        '
        'Pinjam
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSlateGray
        Me.ClientSize = New System.Drawing.Size(727, 645)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.LblBaris)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DGPinjam)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Pinjam"
        Me.Text = "Pinjam"
        CType(Me.DGPinjam, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DGPinjam As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtnokendaraan As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtkdmobil As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents tglpinjam As DateTimePicker
    Friend WithEvents txtkdadmin As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txttelepon As TextBox
    Friend WithEvents txtalamat As TextBox
    Friend WithEvents txtkdpelanggan As TextBox
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtsisabayar As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents tglkembali As DateTimePicker
    Friend WithEvents txtkdpinjam As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents kdpinjam As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btntambah As Button
    Friend WithEvents btnBatal As Button
    Friend WithEvents btnsimpan As Button
    Friend WithEvents BtnTutup As Button
    Friend WithEvents CmbPelanggan As ComboBox
    Friend WithEvents LblSelisih As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Bayar As TextBox
    Friend WithEvents txtHarga As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnhapus As Button
    Friend WithEvents btnubah As Button
    Friend WithEvents LblBaris As Label
    Friend WithEvents txtpinjam As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents txtmerkmobil As TextBox
    Friend WithEvents btnmobil As Button
    Friend WithEvents btnhitung As Button
End Class
