﻿Public Class CariTransaksi
    Dim modeProses As Integer
    Dim baris As Integer
    Private Sub CariTransaksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefreshGrid()
    End Sub

    Private Sub RefreshGrid()
        DTGrid = KontrolPinjam.TampilData.ToTable
        DGTransaksi.DataSource = DTGrid

        If DTGrid.Rows.Count > 0 Then
            baris = DTGrid.Rows.Count - 1
            DGTransaksi.Rows(DTGrid.Rows.Count - 1).Selected = True
            DGTransaksi.CurrentCell = DGTransaksi.Item(1, baris)

        End If
    End Sub


    Private Sub Isibox(br As Integer)

        If br < DTGrid.Rows.Count Then
            With DGTransaksi.Rows(br)
                Kembali.txtkdpinjam.Text = .Cells(0).Value.ToString
                Kembali.tgldeadline.Text = .Cells(10).Value.ToString
                Kembali.txtnamapeminjam.Text = .Cells(6).Value.ToString
                Kembali.txtmobil.Text = .Cells(3).Value.ToString
                'Kembali.txthargasewa.Text = .Cells(11).Value.ToString
                'Kembali.txtharga.Text = .Cells(13).Value.ToString
                Kembali.txtkdmobil.Text = .Cells(2).Value.ToString
            End With

        End If
    End Sub

    Private Sub DGTransaksi_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGTransaksi.CellDoubleClick
        DTGrid = KontrolPinjam.TampilData.ToTable
        baris = e.RowIndex
        DGTransaksi.Rows(baris).Selected = True
        Isibox(baris)
        Me.Visible = False

        Kembali.tglkembali.Focus()
    End Sub



End Class