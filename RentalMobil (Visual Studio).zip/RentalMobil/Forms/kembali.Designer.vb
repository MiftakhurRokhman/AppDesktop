﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Kembali
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DGKembali = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtkdmobil = New System.Windows.Forms.TextBox()
        Me.txtkdkembali = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.hargadenda = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tgldeadline = New System.Windows.Forms.DateTimePicker()
        Me.txtmobil = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtnamapeminjam = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblhari = New System.Windows.Forms.Label()
        Me.tglkembali = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtcatatan = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtkdpinjam = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txthargabaru = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.terlambat = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnhapus = New System.Windows.Forms.Button()
        Me.btntambah = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.BtnTutup = New System.Windows.Forms.Button()
        Me.btnubah = New System.Windows.Forms.Button()
        CType(Me.DGKembali, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'DGKembali
        '
        Me.DGKembali.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGKembali.Location = New System.Drawing.Point(31, 395)
        Me.DGKembali.Margin = New System.Windows.Forms.Padding(2)
        Me.DGKembali.Name = "DGKembali"
        Me.DGKembali.RowTemplate.Height = 24
        Me.DGKembali.Size = New System.Drawing.Size(585, 160)
        Me.DGKembali.TabIndex = 76
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtkdmobil)
        Me.GroupBox1.Controls.Add(Me.txtkdkembali)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.hargadenda)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.tgldeadline)
        Me.GroupBox1.Controls.Add(Me.txtmobil)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtnamapeminjam)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.lblhari)
        Me.GroupBox1.Controls.Add(Me.tglkembali)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtcatatan)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtkdpinjam)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txthargabaru)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.terlambat)
        Me.GroupBox1.Location = New System.Drawing.Point(32, 39)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(584, 252)
        Me.GroupBox1.TabIndex = 89
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(323, 119)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 123
        Me.Button2.Text = "Hitung"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(320, 80)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(60, 13)
        Me.Label16.TabIndex = 122
        Me.Label16.Text = "Kode Mobil"
        '
        'txtkdmobil
        '
        Me.txtkdmobil.Location = New System.Drawing.Point(437, 73)
        Me.txtkdmobil.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkdmobil.Name = "txtkdmobil"
        Me.txtkdmobil.Size = New System.Drawing.Size(122, 20)
        Me.txtkdmobil.TabIndex = 121
        '
        'txtkdkembali
        '
        Me.txtkdkembali.Location = New System.Drawing.Point(105, 17)
        Me.txtkdkembali.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkdkembali.Name = "txtkdkembali"
        Me.txtkdkembali.Size = New System.Drawing.Size(197, 20)
        Me.txtkdkembali.TabIndex = 119
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(13, 22)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 13)
        Me.Label14.TabIndex = 120
        Me.Label14.Text = "Kode Kembali"
        '
        'hargadenda
        '
        Me.hargadenda.Location = New System.Drawing.Point(193, 153)
        Me.hargadenda.Margin = New System.Windows.Forms.Padding(2)
        Me.hargadenda.Name = "hargadenda"
        Me.hargadenda.Size = New System.Drawing.Size(112, 20)
        Me.hargadenda.TabIndex = 116
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(133, 156)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 115
        Me.Label5.Text = "Denda"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(13, 87)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(86, 13)
        Me.Label12.TabIndex = 112
        Me.Label12.Text = "Tanggal Kembali"
        '
        'tgldeadline
        '
        Me.tgldeadline.Location = New System.Drawing.Point(106, 82)
        Me.tgldeadline.Margin = New System.Windows.Forms.Padding(2)
        Me.tgldeadline.Name = "tgldeadline"
        Me.tgldeadline.Size = New System.Drawing.Size(199, 20)
        Me.tgldeadline.TabIndex = 111
        '
        'txtmobil
        '
        Me.txtmobil.Location = New System.Drawing.Point(437, 48)
        Me.txtmobil.Margin = New System.Windows.Forms.Padding(2)
        Me.txtmobil.Name = "txtmobil"
        Me.txtmobil.Size = New System.Drawing.Size(122, 20)
        Me.txtmobil.TabIndex = 108
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(321, 55)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 13)
        Me.Label9.TabIndex = 107
        Me.Label9.Text = "Mobil"
        '
        'txtnamapeminjam
        '
        Me.txtnamapeminjam.Location = New System.Drawing.Point(437, 22)
        Me.txtnamapeminjam.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnamapeminjam.Name = "txtnamapeminjam"
        Me.txtnamapeminjam.Size = New System.Drawing.Size(122, 20)
        Me.txtnamapeminjam.TabIndex = 106
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(321, 26)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(83, 13)
        Me.Label10.TabIndex = 105
        Me.Label10.Text = "Nama Peminjam"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(279, 45)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(23, 23)
        Me.Button1.TabIndex = 104
        Me.Button1.Text = "."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(103, 156)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(26, 13)
        Me.Label7.TabIndex = 103
        Me.Label7.Text = "Hari"
        '
        'lblhari
        '
        Me.lblhari.AutoSize = True
        Me.lblhari.Location = New System.Drawing.Point(86, 156)
        Me.lblhari.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblhari.Name = "lblhari"
        Me.lblhari.Size = New System.Drawing.Size(13, 13)
        Me.lblhari.TabIndex = 102
        Me.lblhari.Text = "0"
        '
        'tglkembali
        '
        Me.tglkembali.Location = New System.Drawing.Point(107, 120)
        Me.tglkembali.Margin = New System.Windows.Forms.Padding(2)
        Me.tglkembali.Name = "tglkembali"
        Me.tglkembali.Size = New System.Drawing.Size(198, 20)
        Me.tglkembali.TabIndex = 101
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(11, 124)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 13)
        Me.Label8.TabIndex = 100
        Me.Label8.Text = "Tanggal Terlambat"
        '
        'txtcatatan
        '
        Me.txtcatatan.Location = New System.Drawing.Point(105, 210)
        Me.txtcatatan.Name = "txtcatatan"
        Me.txtcatatan.Size = New System.Drawing.Size(200, 20)
        Me.txtcatatan.TabIndex = 99
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 213)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 98
        Me.Label4.Text = "Catatan"
        '
        'txtkdpinjam
        '
        Me.txtkdpinjam.Location = New System.Drawing.Point(105, 46)
        Me.txtkdpinjam.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkdpinjam.Name = "txtkdpinjam"
        Me.txtkdpinjam.Size = New System.Drawing.Size(168, 20)
        Me.txtkdpinjam.TabIndex = 94
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 51)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 95
        Me.Label2.Text = "Kode Pinjam"
        '
        'txthargabaru
        '
        Me.txthargabaru.Location = New System.Drawing.Point(105, 180)
        Me.txthargabaru.Margin = New System.Windows.Forms.Padding(2)
        Me.txthargabaru.Name = "txthargabaru"
        Me.txthargabaru.Size = New System.Drawing.Size(200, 20)
        Me.txthargabaru.TabIndex = 90
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 183)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 90
        Me.Label6.Text = "Total Harga"
        '
        'terlambat
        '
        Me.terlambat.AutoSize = True
        Me.terlambat.Location = New System.Drawing.Point(13, 156)
        Me.terlambat.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.terlambat.Name = "terlambat"
        Me.terlambat.Size = New System.Drawing.Size(54, 13)
        Me.terlambat.TabIndex = 91
        Me.terlambat.Text = "Terlambat"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(30, 12)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 24)
        Me.Label1.TabIndex = 94
        Me.Label1.Text = "Pengembalian"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnubah)
        Me.GroupBox2.Controls.Add(Me.btnhapus)
        Me.GroupBox2.Controls.Add(Me.btntambah)
        Me.GroupBox2.Controls.Add(Me.btnBatal)
        Me.GroupBox2.Controls.Add(Me.btnsimpan)
        Me.GroupBox2.Controls.Add(Me.BtnTutup)
        Me.GroupBox2.Location = New System.Drawing.Point(31, 296)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(585, 94)
        Me.GroupBox2.TabIndex = 95
        Me.GroupBox2.TabStop = False
        '
        'btnhapus
        '
        Me.btnhapus.Image = Global.RentalMobil.My.Resources.Resources.hapus2
        Me.btnhapus.Location = New System.Drawing.Point(446, 17)
        Me.btnhapus.Margin = New System.Windows.Forms.Padding(2)
        Me.btnhapus.Name = "btnhapus"
        Me.btnhapus.Size = New System.Drawing.Size(73, 64)
        Me.btnhapus.TabIndex = 124
        Me.btnhapus.Text = "Hapus"
        Me.btnhapus.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnhapus.UseVisualStyleBackColor = True
        '
        'btntambah
        '
        Me.btntambah.Image = Global.RentalMobil.My.Resources.Resources.tambah1
        Me.btntambah.Location = New System.Drawing.Point(54, 18)
        Me.btntambah.Margin = New System.Windows.Forms.Padding(2)
        Me.btntambah.Name = "btntambah"
        Me.btntambah.Size = New System.Drawing.Size(70, 63)
        Me.btntambah.TabIndex = 96
        Me.btntambah.Text = "Tambah"
        Me.btntambah.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btntambah.UseVisualStyleBackColor = True
        '
        'btnBatal
        '
        Me.btnBatal.Image = Global.RentalMobil.My.Resources.Resources.close2
        Me.btnBatal.Location = New System.Drawing.Point(284, 18)
        Me.btnBatal.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(77, 63)
        Me.btnBatal.TabIndex = 15
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'btnsimpan
        '
        Me.btnsimpan.Image = Global.RentalMobil.My.Resources.Resources.Save21
        Me.btnsimpan.Location = New System.Drawing.Point(198, 18)
        Me.btnsimpan.Margin = New System.Windows.Forms.Padding(2)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(82, 63)
        Me.btnsimpan.TabIndex = 12
        Me.btnsimpan.Text = "Simpan"
        Me.btnsimpan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'BtnTutup
        '
        Me.BtnTutup.Image = Global.RentalMobil.My.Resources.Resources.close2
        Me.BtnTutup.Location = New System.Drawing.Point(367, 18)
        Me.BtnTutup.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnTutup.Name = "BtnTutup"
        Me.BtnTutup.Size = New System.Drawing.Size(75, 63)
        Me.BtnTutup.TabIndex = 44
        Me.BtnTutup.Text = "Tutup"
        Me.BtnTutup.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnTutup.UseVisualStyleBackColor = True
        '
        'btnubah
        '
        Me.btnubah.Image = Global.RentalMobil.My.Resources.Resources.edit2
        Me.btnubah.Location = New System.Drawing.Point(128, 17)
        Me.btnubah.Margin = New System.Windows.Forms.Padding(2)
        Me.btnubah.Name = "btnubah"
        Me.btnubah.Size = New System.Drawing.Size(63, 64)
        Me.btnubah.TabIndex = 125
        Me.btnubah.Text = "Ubah"
        Me.btnubah.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnubah.UseVisualStyleBackColor = True
        '
        'Kembali
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSlateGray
        Me.ClientSize = New System.Drawing.Size(657, 566)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DGKembali)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Kembali"
        Me.Text = "Kembali"
        CType(Me.DGKembali, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DGKembali As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents terlambat As Label
    Friend WithEvents txthargabaru As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnBatal As Button
    Friend WithEvents btnsimpan As Button
    Friend WithEvents BtnTutup As Button
    Friend WithEvents txtkdpinjam As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtcatatan As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents lblhari As Label
    Friend WithEvents tglkembali As DateTimePicker
    Friend WithEvents Label8 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents tgldeadline As DateTimePicker
    Friend WithEvents txtmobil As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtnamapeminjam As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents hargadenda As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtkdkembali As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents btntambah As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents txtkdmobil As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents btnhapus As Button
    Friend WithEvents btnubah As Button
End Class
