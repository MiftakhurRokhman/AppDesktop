﻿Imports System.Data.OleDb
Imports RentalMobil

Public Class ClsCtlMobil : Implements InfProses

    Function kodeBaru() As String
        Dim kodeakhir As Integer
        Try
            DTA = New OleDbDataAdapter("select max(right(kode_mobil,4)) from mobil", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "max_kode")
            kodeakhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            kodeBaru = "M" & Strings.Right("000" & kodeakhir + 1, 4)
            Return kodeBaru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function CariData(kunci As String) As OleDbCommand Implements InfProses.CariData
        Throw New NotImplementedException()
    End Function

    Public Function DeleteData(kunci As String) As OleDbCommand Implements InfProses.DeleteData
        CMD = New OleDbCommand("delete from mobil " _
                             & " where kode_mobil='" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntMobil
        data = Ob
        CMD = New OleDbCommand("insert into mobil values('" & data.KodeMobil & "','" _
                                & data.MerkMobil & "','" & data.NomorKendaraan & "','" _
                                & data.Warnamobil & "','" & data.TarifMobil & "','" _
                                & data.TahunMobil & "','" & data.StatusMobil & "')", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData() As DataView Implements InfProses.TampilData

        Try
            DTA = New OleDbDataAdapter("Select * from MOBIL ", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_Mobil")
            Dim grid As New DataView(DTS.Tables("Tabel_Mobil"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try

        Throw New NotImplementedException()
    End Function
    Function cekMobilDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("Select count(kode_mobil) from mobil " _
                                       & "where kode_mobil='" & kunci & "'", BUKAKONEKSI)

            DTS = New DataSet()
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 1 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)

        End Try
        Return cek
    End Function
    Public Function updateData(Ob As Object) As OleDbCommand Implements InfProses.UpdateData
        Dim data As New ClsEntMobil
        data = Ob
        CMD = New OleDbCommand("update mobil set merk_mobil = '" _
                            & data.MerkMobil & "', nomor_kendaraan='" & data.NomorKendaraan _
                            & "', warna_mobil='" & data.Warnamobil _
                             & "', tarif_mobil='" & data.TarifMobil _
                              & "', tahun_mobil='" & data.TahunMobil _
                              & "', status_mobil='" & data.StatusMobil _
                            & " 'where kode_mobil ='" & data.KodeMobil & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData1() As DataView Implements InfProses.TampilData1
        Try
            DTA = New OleDbDataAdapter("Select * from MOBIL where status_mobil ='Tersedia' ", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_Mobil")
            Dim grid As New DataView(DTS.Tables("Tabel_Mobil"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try

        Throw New NotImplementedException()

    End Function
End Class
