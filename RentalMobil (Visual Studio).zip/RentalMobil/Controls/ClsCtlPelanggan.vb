﻿Imports System.Data.OleDb
Imports RentalMobil

Public Class ClsCtlPelanggan : Implements InfProses

    Function kodeBaru() As String
        Dim kodeakhir As Integer
        Try
            DTA = New OleDbDataAdapter("select max(right(kode_pelanggan,4)) from pelanggan", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "max_kode")
            kodeakhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            kodeBaru = "P" & Strings.Right("000" & kodeakhir + 1, 4)
            Return kodeBaru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function CariData(kunci As String) As OleDbCommand Implements InfProses.CariData
        Throw New NotImplementedException()
    End Function

    Public Function DeleteData(kunci As String) As OleDbCommand Implements InfProses.DeleteData
        CMD = New OleDbCommand("delete from pelanggan " _
                             & " where kode_pelanggan='" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntPelanggan
        data = Ob
        CMD = New OleDbCommand("insert into pelanggan values('" & data.KodePelanggan & "','" _
                                & data.NomorKtp & "','" & data.NamaPelanggan & "','" _
                                & data.AlamatPelanggan & "','" & data.JenisKelamin & "','" _
                                & data.TeleponPelanggan & "')", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData() As DataView Implements InfProses.TampilData

        Try
            DTA = New OleDbDataAdapter("Select * from PELANGGAN ", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_Pelanggan")
            Dim grid As New DataView(DTS.Tables("Tabel_Pelanggan"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try

        Throw New NotImplementedException()
    End Function
    Function cekPelangganDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("Select count(kode_pelanggan) from pelanggan " _
                                       & "where kode_pelanggan='" & kunci & "'", BUKAKONEKSI)

            DTS = New DataSet()
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 1 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)

        End Try
        Return cek
    End Function
    Public Function updateData(Ob As Object) As OleDbCommand Implements InfProses.UpdateData
        Dim data As New ClsEntPelanggan
        data = Ob
        CMD = New OleDbCommand("update pelanggan set nomor_ktp = '" & data.NomorKtp _
                            & "', nama_pengguna ='" & data.NamaPelanggan _
                            & "', alamat='" & data.AlamatPelanggan _
                             & "', jenis_kelamin='" & data.JenisKelamin _
                              & "', telepon='" & data.TeleponPelanggan _
                            & "' where kode_pelanggan ='" & data.KodePelanggan & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData1() As DataView Implements InfProses.TampilData1
        Throw New NotImplementedException()
    End Function
End Class
