﻿Imports System.Data.OleDb
Imports RentalMobil

Public Class ClsCtlPinjam : Implements InfProses

    Function kodeBaru() As String
        Dim kodeakhir As Integer
        Try
            DTA = New OleDbDataAdapter("select max(right(kode_pinjam,4)) from pinjam", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "max_kode")
            kodeakhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            kodeBaru = "T" & Strings.Right("000" & kodeakhir + 1, 4)
            Return kodeBaru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function CariData(kunci As String) As OleDbCommand Implements InfProses.CariData
        Throw New NotImplementedException()
    End Function

    Public Function DeleteData(kunci As String) As OleDbCommand Implements InfProses.DeleteData
        CMD = New OleDbCommand("delete from pinjam " _
                             & " where kode_pinjam ='" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntPinjam
        data = Ob
        CMD = New OleDbCommand("insert into pinjam values('" & data.KodePinjam & "','" _
                                & data.KodeAdmin & "','" & data.KodeMobil & "','" _
                                & data.TglPinjam & "','" & data.TglKembali & "','" _
                                & data.KodePelanggan & "'," & data.BayarPelanggan & ",'" _
                                & data.StatusPinjam & "')", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData() As DataView Implements InfProses.TampilData
        Try
            DTA = New OleDbDataAdapter("select p.KODE_PINJAM , p.KODE_ADMIN , p.KODE_MOBIL , m.MERK_MOBIL , m.NOMOR_KENDARAAN  , e.KODE_PELANGGAN
	            , e.NAMA_PENGGUNA , e.ALAMAT , e.TELEPON , p.TGL_PINJAM , p.TGL_KEMBALI , p.BAYAR , p.STATUS_PINJAM, m.TARIF_MOBIL
                   from PINJAM p join mobil m on p.KODE_MOBIL = m.KODE_MOBIL join PELANGGAN e on e.KODE_PELANGGAN = p.KODE_PELANGGAN where STATUS_PINJAM = 'Pinjam'
                    ", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_pinjam")
            Dim grid As New DataView(DTS.Tables("Tabel_pinjam"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try

        Throw New NotImplementedException()
    End Function

    Function cekPelangganDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("Select count(kode_pinjam) from pinjam " _
                                       & "where kode_pinjam='" & kunci & "'", BUKAKONEKSI)

            DTS = New DataSet()
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 1 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)

        End Try
        Return cek
    End Function

    Public Function updateData(Ob As Object) As OleDbCommand Implements InfProses.UpdateData
        Dim data As New ClsEntPinjam
        data = Ob
        CMD = New OleDbCommand("update pinjam set kode_admin = '" _
                            & data.KodeAdmin & "', kode_mobil ='" & data.KodeMobil _
                            & "', tgl_pinjam ='" & data.TglPinjam & "', tgl_kembali ='" & data.TglKembali _
                              & "', kode_pelanggan ='" & data.KodePelanggan _
                              & "', Bayar ='" & data.BayarPelanggan _
                               & "', Status_pinjam ='" & data.StatusPinjam _
                            & " 'where kode_pinjam  ='" & data.KodePinjam & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData1() As DataView Implements InfProses.TampilData1
        Throw New NotImplementedException()
    End Function
End Class
