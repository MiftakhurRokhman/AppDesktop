﻿Imports System.Data.OleDb
Public Interface InfProses
    Function InsertData(Ob As Object) As OleDbCommand
    Function UpdateData(Ob As Object) As OleDbCommand
    Function DeleteData(kunci As String) As OleDbCommand
    Function TampilData() As DataView
    Function TampilData1() As DataView
    Function CariData(kunci As String) As OleDbCommand
End Interface
