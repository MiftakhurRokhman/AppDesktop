﻿Imports System.Data.OleDb
Imports RentalMobil

Public Class ClsCtlKembali : Implements InfProses

    Function kodeBaru() As String
        Dim kodeakhir As Integer
        Try
            DTA = New OleDbDataAdapter("select max(right(kode_kembali,4)) from kembali", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "max_kode")
            kodeakhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            kodeBaru = "K" & Strings.Right("000" & kodeakhir + 1, 4)
            Return kodeBaru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Function updatestatus(ob As Object) As OleDbCommand
        Dim data As New ClsEntPinjam
        data = ob
        CMD = New OleDbCommand("update pinjam set status_pinjam = '" _
                               & data.StatusPinjam _
                           & " 'where kode_pinjam  ='" & data.KodePinjam & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Function cekKembaliDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("Select count(kode_kembali) from kembali " _
                                       & "where kode_kembali='" & kunci & "'", BUKAKONEKSI)

            DTS = New DataSet()
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 1 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)

        End Try
        Return cek
    End Function

    Function updatemobil(ob As Object) As OleDbCommand
        Dim data As New ClsEntMobil
        data = ob
        CMD = New OleDbCommand("update mobil set status_mobil = '" _
                               & data.StatusMobil _
                           & " 'where kode_mobil  ='" & data.KodeMobil & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function
    Public Function CariData(kunci As String) As OleDbCommand Implements InfProses.CariData
        Throw New NotImplementedException()
    End Function

    Public Function DeleteData(kunci As String) As OleDbCommand Implements InfProses.DeleteData
        CMD = New OleDbCommand("delete from kembali " _
                             & " where kode_kembali='" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntKembali
        data = Ob
        CMD = New OleDbCommand("insert into kembali values('" & data.KodeDenda & "','" _
                                & data.KodePinjam & "','" & data.Tgl_Kembali & "','" _
                                & data.TerlambatDenda & "','" & data.CatatanDenda & "'," _
                                & data.Dendaharga & "," & data.TotalBayar & ")", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData() As DataView Implements InfProses.TampilData
        Try
            DTA = New OleDbDataAdapter("select d.KODE_KEMBALI, p.KODE_PINJAM , p.KODE_MOBIL , m.MERK_MOBIL , e.KODE_PELANGGAN
	            , e.NAMA_PENGGUNA , e.ALAMAT , e.TELEPON , p.TGL_PINJAM , p.TGL_KEMBALI ,d.TGL_KEMBALI,d.TERLAMBAT, p.BAYAR ,d.DENDA, d.TOTAL_BAYAR , p.STATUS_PINJAM, d.CATATAN
                   from PINJAM p join mobil m 
				   on p.KODE_MOBIL = m.KODE_MOBIL 
				   join PELANGGAN e 
				   on e.KODE_PELANGGAN = p.KODE_PELANGGAN 
				   join KEMBALI d 
				   on p.KODE_PINJAM = d.KODE_PINJAM
                    ", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_kembali")
            Dim grid As New DataView(DTS.Tables("Tabel_kembali"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try

        Throw New NotImplementedException()
    End Function

    Public Function UpdateData(Ob As Object) As OleDbCommand Implements InfProses.UpdateData
        Dim data As New ClsEntKembali
        data = Ob
        CMD = New OleDbCommand("update kembali set tgl_kembali = '" _
                            & data.Tgl_Kembali & "', catatan='" & data.CatatanDenda _
                            & " 'where kode_kembali ='" & data.KodeDenda & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function TampilData1() As DataView Implements InfProses.TampilData1
        Throw New NotImplementedException()
    End Function
End Class
