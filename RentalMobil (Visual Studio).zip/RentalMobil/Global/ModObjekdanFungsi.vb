﻿Module ModObjekdanFungsi
    Public KontrolMobil As New ClsCtlMobil
    Public EntitasMobil As New ClsEntMobil
    Public EntitasPinjam As New ClsEntPinjam
    Public KontrolPinjam As New ClsCtlPinjam
    Public KontrolPelanggan As New ClsCtlPelanggan
    Public EntitiasPelanggan As New ClsEntPelanggan
    Public KontrolKembali As New ClsCtlKembali
    Public EntitasKembali As New ClsEntKembali


End Module